import React, { Component } from 'react';
import {Link} from "react-router-dom" ;
import './NavBars.css';

function NavBar() {
    return(
        <nav className="NavBar">
            <div ><Link to="/register" className="item">S'enregistrer </Link></div>
            <div ><Link to="/login" className="item">Se connecter</Link></div>
        </nav>
    );

}
  
  export default NavBar;
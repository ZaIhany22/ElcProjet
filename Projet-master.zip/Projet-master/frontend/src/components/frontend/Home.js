import React, { Component } from 'react';
import {Link} from "react-router-dom" ;
import NavBar from '../../NaviBar/front/NavBar';

function Home() {
    return(
        <div >
           <NavBar></NavBar>
           <h1>Home page</h1>
        </div>
        
        
    );

}
  
  export default Home;
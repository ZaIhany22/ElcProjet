import React,{useState} from "react";
import { useHistory } from "react-router-dom";
import './Login.css';
import axios from 'axios';
import swal from 'sweetalert';
import NavBar from "../../../NaviBar/front/NavBar";
function Login() {
    const history=useHistory();
    const[loginEnter,setLogin]=useState({
        email:"" ,
        password:"",
        

    });
const handleInput=(e)=>{
        e.presist() ;
        setLogin({...loginEnter,[e.target.name]: e.target.value }) ;
    }
    const loginSubmit=(e)=>{
        e.preventDefault() ;
        
        const data ={
            email:loginEnter.email,
            password:loginEnter.password,
        }
       
            
      
        axios.post('api/login', data).then(resp =>{ //ito no fonction mifandray amin api.php laravel,stoquer ao am data daolo ny information av an am backend
           
                
                console.log(resp);//rehefa marin ny tapenle ol
                
            } )
                
           
          .catch( err =>  {
                console.log(err);//rehefa marina ny mail fa diso mot de passe
           });   

    }
    return(
       
         <div>
            <NavBar></NavBar>
           <div className="Container">
              
            <p class="texte">Se connecter</p>
               <div class="Container2" >
            <form onSubmit={loginSubmit}>
                    <label for="fname">Addresse e-mail</label>
                    <input type="email" onChange={handleInput} value={loginEnter.email} id="fname" name="email" placeholder="e-mail"/>
                    <label for="lname">Mot de passe</label>
                    <input type="password" onChange={handleInput} value={loginEnter.password} id="lname" name="password" placeholder="mot de passe"/>
                    <input type="submit" value="se connecter"></input>
                </form>
        </div>
           </div>
           </div>
          
    );
        
    
    
}
export default Login ;
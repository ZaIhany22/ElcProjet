import axios from 'axios';
import React, { Component, useState } from 'react';
import {Link} from "react-router-dom" ;
import swal from 'sweetalert';
import NavBar from '../../../NaviBar/front/NavBar';
import './Register.css';

function Register() {
    const [registerInput,setRegister] = useState({
        name:'' ,
        adresse:'',
        email:'',
        password:''

    }) ;
    const handleInput = (e) => {
        e.persist() ;
        setRegister({...registerInput,[e.target.name]:e.target.value}) ;

    }
    const registerSubmit = (e) => {
        e.preventDefault() ;
       const data= {
            name: registerInput.name,
            adresse: registerInput.adresse,
            email: registerInput.email,
            password:registerInput.password,
       }
       axios.get('/sanctum/csrf-cookie').then(response=>{
       axios.post('api/register',data).then(res =>{
           if(res.data.status===201){
               swal("enregistrer") ;
           }
           else{
               swal("n'est pas enregistré") ;
           }

       }) ;
    }) ;

    }
    return(
        <div >
           <NavBar></NavBar>
           <div>
            <form onSubmit={registerSubmit}>
            <div class="regist">Completez vos information</div>
                <div class="container">
                
                <label for="nom"><b >Nom d'utilisateur</b></label>
                <input type="text" onChange={handleInput} value={registerInput.name} placeholder="Nom d'utilisateur" name="name" id="nom" autoFocus />
                
                <label for="adr"><b >Adresse</b></label>
                <input type="text" onChange={handleInput} value={registerInput.adresse} placeholder="adresse" name="adresse" id="adr" required />

                 <label for="email" ><b>Email</b></label>
                <input type="email" onChange={handleInput} value={registerInput.email} placeholder="Votre email" name="email" id="email" required/>

                <label for="photo" ><b>Photo</b></label>
                <input type="file" placeholder="photo" name="photo" id="photo" required/>

                <label for="pwd" ><b>Mot de passe</b></label>
                <input type="password" onChange={handleInput} value={registerInput.password} placeholder="Votre mot de passe" name="password" id="pwd" required/>

                <label for="pwd" ><b>Confirmation mot de passe</b></label>
                <input type="password" placeholder="Retapez votre mot de passe" name="pwd" id="pwd" required/>
                
                <button type="submit" class="registerbtn">Créer mon Compte</button>
                </div>
</form> 
           </div>
        </div>
        
        
    );

}
  
  export default Register;